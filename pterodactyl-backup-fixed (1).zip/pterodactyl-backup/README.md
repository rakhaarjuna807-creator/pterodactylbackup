# 🦕 PteroBackup — Pterodactyl Wings Auto Backup

Auto backup Pterodactyl Wings ke Google Drive via rclone, dengan **OAuth headless** (authorize di PC → paste token ke VPS), penamaan folder otomatis berdasarkan hostname VPS, dan notifikasi Discord.

---

## ✨ Fitur

- ✅ **OAuth headless** — authorize di PC/laptop, paste token ke VPS (no browser di server)
- ✅ **Folder otomatis berdasarkan hostname** — VPS `lite1` → folder Drive `backup-lite1`
- ✅ **Nama archive otomatis** — `ptero-backup_lite1_20260322_020000.tar.gz`
- ✅ **Upload ke Google Drive** via rclone
- ✅ **Auto cleanup** file lama berdasarkan retensi N hari
- ✅ **Discord webhook** — notifikasi start / sukses / gagal
- ✅ **Panel manajemen interaktif** — ubah jadwal, retensi, lihat file Drive
- ✅ **Systemd timer** (lebih reliable dari cron biasa)

---

## 🚀 Cara Pakai

### Di VPS — jalankan installer
```bash
sudo bash install.sh
```

### Di PC/Laptop — authorize Google Drive
Saat installer meminta token, buka terminal di PC dan jalankan:
```bash
bash oauth-helper-pc.sh
```
Script buka browser → login → tampilkan token JSON → copy → paste ke VPS.

### Hasil folder di Drive
```
My Drive/
└── backup-lite1/            ← hostname VPS = lite1
    ├── ptero-backup_lite1_20260322_020000.tar.gz
    └── ptero-backup_lite1_20260323_020000.tar.gz
```

---

## 📋 Penamaan File Backup

| Hostname VPS | Folder Drive | Nama Archive |
|---|---|---|
| `lite1` | `backup-lite1` | `ptero-backup_lite1_YYYYMMDD_HHMMSS.tar.gz` |
| `node-01` | `backup-node-01` | `ptero-backup_node-01_YYYYMMDD_HHMMSS.tar.gz` |
| `server.vps.co` | `backup-server-vps-co` | `ptero-backup_server-vps-co_YYYYMMDD_HHMMSS.tar.gz` |

---

## 🔐 OAuth Headless Flow

```
PC/Laptop                     VPS
─────────                     ───
bash oauth-helper-pc.sh
  └─ buka browser
       └─ login Google
            └─ Allow
                 └─ Token JSON muncul di terminal
                      └─ Copy token
                                    sudo bash install.sh
                                      └─ Paste token JSON
                                           └─ rclone verified ✓
```

---

## 🕹️ Commands

```bash
ptero-backup-manage          # Panel manajemen interaktif
ptero-backup                 # Backup sekarang
ptero-backup-manage status   # Status
ptero-backup-manage logs     # Lihat log
ptero-backup-manage files    # Lihat file di Drive
```

---

## ⚙️ Config — `/etc/ptero-backup/config.env`

```env
BACKUP_SOURCE_DIR="/var/lib/pterodactyl"
GDRIVE_REMOTE="gdrive"
GDRIVE_FOLDER="backup-lite1"    # otomatis dari hostname
RETENTION_DAYS="7"
DISCORD_WEBHOOK_URL="https://discord.com/api/webhooks/..."
```

---

## 🗑️ Uninstall

```bash
ptero-backup-manage   # → menu 9 → ketik HAPUS
```
