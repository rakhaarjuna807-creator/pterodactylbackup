#!/bin/bash
# ============================================================
#  PteroBackup — OAuth Helper (Jalankan di PC/Laptop)
#  Menghasilkan token Google Drive untuk di-paste ke VPS
# ============================================================

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; MAGENTA='\033[0;35m'
NC='\033[0m'; BOLD='\033[1m'; DIM='\033[2m'

line()   { echo -e "${DIM}──────────────────────────────────────────────────────${NC}"; }
ok()     { echo -e "  ${GREEN}✔${NC}  $1"; }
info()   { echo -e "  ${BLUE}ℹ${NC}  $1"; }
warn()   { echo -e "  ${YELLOW}⚠${NC}  $1"; }
err()    { echo -e "  ${RED}✖${NC}  $1"; }

clear
echo -e "${BOLD}${CYAN}"
echo "  ╔══════════════════════════════════════════════════════╗"
echo "  ║   🔐  PteroBackup — Google Drive OAuth Helper        ║"
echo "  ║       Jalankan script ini di PC/Laptop kamu!         ║"
echo "  ╚══════════════════════════════════════════════════════╝"
echo -e "${NC}"
line
echo ""
echo -e "  Script ini akan:"
echo -e "  ${DIM}1. Buka browser → login Google Drive${NC}"
echo -e "  ${DIM}2. Tampilkan token JSON di terminal${NC}"
echo -e "  ${DIM}3. Kamu copy token → paste ke VPS${NC}"
echo ""
line
echo ""

# ── Cek rclone ───────────────────────────────────────────────
if ! command -v rclone &>/dev/null; then
    err "rclone tidak ada di PC ini!"
    echo ""
    echo -e "  ${BOLD}Install rclone dulu:${NC}"
    echo -e "  ${CYAN}Windows :${NC} Download di https://rclone.org/downloads/"
    echo -e "  ${CYAN}macOS   :${NC} ${YELLOW}brew install rclone${NC}"
    echo -e "  ${CYAN}Linux   :${NC} ${YELLOW}curl https://rclone.org/install.sh | sudo bash${NC}"
    echo ""
    exit 1
fi

RCLONE_VER=$(rclone version 2>/dev/null | head -1)
ok "rclone: $RCLONE_VER"
echo ""

# ── Tanya Client ID/Secret ────────────────────────────────────
echo -e "  ${BOLD}Pakai OAuth App sendiri atau bawaan rclone?${NC}"
echo ""
echo -e "  ${CYAN}1)${NC} Bawaan rclone ${DIM}(cepat)${NC}"
echo -e "  ${CYAN}2)${NC} OAuth App sendiri ${DIM}(direkomendasikan produksi)${NC}"
echo ""
read -rp "  → Pilihan [1/2]: " oauth_choice

CLIENT_ID="" CLIENT_SECRET=""
if [ "$oauth_choice" = "2" ]; then
    echo ""
    read -rp "  → Client ID     : " CLIENT_ID
    read -rsp "  → Client Secret : " CLIENT_SECRET
    echo ""
fi

# ── Jalankan rclone authorize ────────────────────────────────
echo ""
echo -e "  ${BOLD}${GREEN}🌐 Membuka browser untuk login Google Drive...${NC}"
echo ""
echo -e "  ${DIM}Jika browser tidak terbuka otomatis, copy URL yang muncul${NC}"
echo -e "  ${DIM}di terminal dan buka manual di browser.${NC}"
echo ""
read -rp "  Tekan ENTER untuk mulai..."
echo ""
line
echo ""

# Jalankan rclone authorize — ini yang generate token
# Output token akan muncul di terminal persis seperti rclone config
if [ -n "$CLIENT_ID" ] && [ -n "$CLIENT_SECRET" ]; then
    rclone authorize "drive" "$CLIENT_ID" "$CLIENT_SECRET"
else
    rclone authorize "drive"
fi

echo ""
line
echo ""
echo -e "  ${BOLD}${GREEN}✅ Selesai!${NC}"
echo ""
echo -e "  ${BOLD}Sekarang:${NC}"
echo -e "  ${DIM}1. Copy token JSON di atas (dari { sampai })${NC}"
echo -e "  ${DIM}2. Kembali ke terminal VPS${NC}"
echo -e "  ${DIM}3. Paste di prompt ${BOLD}config_token>${NC}"
echo ""
