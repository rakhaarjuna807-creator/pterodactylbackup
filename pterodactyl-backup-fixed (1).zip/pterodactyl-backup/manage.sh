#!/bin/bash
# ============================================================
#  PteroBackup — Management Panel
#  ptero-backup-manage
# ============================================================

CONFIG_FILE="/etc/ptero-backup/config.env"
LOG_FILE="/var/log/ptero-backup/backup.log"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; MAGENTA='\033[0;35m'
NC='\033[0m'; BOLD='\033[1m'; DIM='\033[2m'

line()   { echo -e "${DIM}──────────────────────────────────────────────────────${NC}"; }
header() { echo -e "\n${BOLD}${CYAN} $1${NC}"; line; }
ok()     { echo -e "  ${GREEN}✔${NC}  $1"; }
info()   { echo -e "  ${BLUE}ℹ${NC}  $1"; }
warn()   { echo -e "  ${YELLOW}⚠${NC}  $1"; }
err()    { echo -e "  ${RED}✖${NC}  $1"; }

load_config() {
    if [ -f "$CONFIG_FILE" ]; then
        source "$CONFIG_FILE"
    else
        err "Config tidak ditemukan. Jalankan installer dulu."
        exit 1
    fi
}

print_header() {
    clear
    echo -e "${BOLD}${CYAN}"
    echo "  ╔══════════════════════════════════════════╗"
    echo "  ║   🦕  PteroBackup Management Panel       ║"
    echo "  ╚══════════════════════════════════════════╝"
    echo -e "${NC}"
}

show_status() {
    load_config
    print_header
    header "📊 Status Sistem"

    # Backup source
    if [ -d "$BACKUP_SOURCE_DIR" ]; then
        SOURCE_SIZE=$(du -sh "$BACKUP_SOURCE_DIR" 2>/dev/null | cut -f1)
        ok "Source: $BACKUP_SOURCE_DIR (${SOURCE_SIZE})"
    else
        err "Source tidak ditemukan: $BACKUP_SOURCE_DIR"
    fi

    # rclone
    if command -v rclone &>/dev/null; then
        RCLONE_VER=$(rclone version 2>/dev/null | head -1 | awk '{print $2}')
        ok "rclone: $RCLONE_VER"

        # Drive connection
        if rclone lsd "${GDRIVE_REMOTE}:" > /dev/null 2>&1; then
            ok "Google Drive: Terhubung (remote: $GDRIVE_REMOTE)"
            DRIVE_COUNT=$(rclone ls "${GDRIVE_REMOTE}:${GDRIVE_FOLDER}/" 2>/dev/null | wc -l)
            info "  Backup di Drive: ${DRIVE_COUNT} file(s) di /${GDRIVE_FOLDER}"
        else
            err "Google Drive: Tidak terhubung (remote: $GDRIVE_REMOTE)"
        fi
    else
        err "rclone tidak terinstall"
    fi

    # Systemd timer
    echo ""
    header "⏰ Jadwal Timer"
    if systemctl is-active --quiet ptero-backup.timer 2>/dev/null; then
        ok "Timer aktif"
        NEXT_RUN=$(systemctl list-timers ptero-backup.timer --no-pager 2>/dev/null | grep ptero | awk '{print $1, $2}')
        info "Next run: ${NEXT_RUN:-tidak diketahui}"
    else
        warn "Timer tidak aktif"
    fi

    # Log tail
    echo ""
    header "📋 Log Terbaru (10 baris)"
    if [ -f "$LOG_FILE" ]; then
        tail -10 "$LOG_FILE" | sed 's/^/  /'
    else
        warn "Log belum ada."
    fi

    echo ""
}

run_backup_now() {
    load_config
    print_header
    header "▶️  Menjalankan Backup Sekarang"
    echo ""
    info "Memulai backup... (bisa beberapa menit)"
    echo ""
    /usr/local/bin/ptero-backup
    echo ""
    ok "Selesai! Cek log: $LOG_FILE"
}

list_drive_files() {
    load_config
    print_header
    header "☁️  Backup di Google Drive"
    echo ""
    if rclone ls "${GDRIVE_REMOTE}:${GDRIVE_FOLDER}/" 2>/dev/null | sort -k2; then
        echo ""
        TOTAL=$(rclone ls "${GDRIVE_REMOTE}:${GDRIVE_FOLDER}/" 2>/dev/null | wc -l)
        info "Total: $TOTAL file(s)"
    else
        warn "Folder kosong atau tidak terhubung."
    fi
    echo ""
}

change_schedule() {
    load_config
    print_header
    header "⏰ Ubah Jadwal Backup"
    echo ""
    echo -e "  ${BOLD}Pilih jadwal baru:${NC}"
    echo -e "  ${CYAN}1)${NC} Setiap 2 jam"
    echo -e "  ${CYAN}2)${NC} Setiap 6 jam"
    echo -e "  ${CYAN}3)${NC} Setiap 12 jam"
    echo -e "  ${CYAN}4)${NC} Setiap 24 jam (jam 02:00)"
    echo -e "  ${CYAN}5)${NC} Custom cron expression"
    echo ""
    read -rp "  → Pilihan [1-5]: " choice

    case "$choice" in
        1) NEW_CRON="0 */2 * * *";  NEW_CAL="*-*-* 00,02,04,06,08,10,12,14,16,18,20,22:00:00"; DESC="Setiap 2 jam" ;;
        2) NEW_CRON="0 */6 * * *";  NEW_CAL="*-*-* 00,06,12,18:00:00"; DESC="Setiap 6 jam" ;;
        3) NEW_CRON="0 */12 * * *"; NEW_CAL="*-*-* 00,12:00:00"; DESC="Setiap 12 jam" ;;
        4) NEW_CRON="0 2 * * *";    NEW_CAL="*-*-* 02:00:00"; DESC="Setiap hari jam 02:00" ;;
        5)
            read -rp "  → Cron expression: " NEW_CRON
            NEW_CAL="*-*-* 02:00:00"
            DESC="Custom: $NEW_CRON"
            ;;
        *) warn "Pilihan tidak valid."; return ;;
    esac

    # Update crontab
    sed -i '/ptero-backup/d' /etc/crontab 2>/dev/null || true
    echo "$NEW_CRON root /usr/local/bin/ptero-backup >> $LOG_FILE 2>&1" >> /etc/crontab

    # Update systemd timer
    sed -i "s|OnCalendar=.*|OnCalendar=${NEW_CAL}|" /etc/systemd/system/ptero-backup.timer 2>/dev/null || true
    systemctl daemon-reload > /dev/null 2>&1
    systemctl restart ptero-backup.timer > /dev/null 2>&1

    ok "Jadwal diubah: $DESC ($NEW_CRON)"
    echo ""
}

update_webhook() {
    load_config
    print_header
    header "🔔 Update Discord Webhook"
    echo ""
    info "Webhook saat ini: ${DISCORD_WEBHOOK_URL:-(tidak ada)}"
    echo ""
    read -rp "  → Webhook URL baru (kosongkan untuk hapus): " NEW_WEBHOOK

    sed -i "s|DISCORD_WEBHOOK_URL=.*|DISCORD_WEBHOOK_URL=\"${NEW_WEBHOOK}\"|" "$CONFIG_FILE"
    ok "Webhook diperbarui."

    if [ -n "$NEW_WEBHOOK" ]; then
        # Test
        curl -s -X POST \
            -H "Content-Type: application/json" \
            -d '{
              "username": "PteroBackup 🦕",
              "embeds": [{
                "title": "🔔 Webhook Diperbarui",
                "description": "Konfigurasi webhook berhasil diperbarui!",
                "color": 3066993
              }]
            }' \
            "$NEW_WEBHOOK" > /dev/null 2>&1 && ok "Test webhook berhasil!" || warn "Gagal kirim test."
    fi
    echo ""
}

update_retention() {
    load_config
    print_header
    header "🗑️  Update Retensi Backup"
    echo ""
    info "Retensi Drive saat ini: ${RETENTION_DAYS} hari"
    info "Retensi lokal saat ini: ${LOCAL_RETENTION_DAYS} hari"
    echo ""
    read -rp "  → Retensi Drive baru (hari, 0=jangan hapus): " NEW_RET
    read -rp "  → Retensi lokal baru (hari): " NEW_LOC_RET

    [ -n "$NEW_RET" ] && sed -i "s|RETENTION_DAYS=.*|RETENTION_DAYS=\"${NEW_RET}\"|" "$CONFIG_FILE"
    [ -n "$NEW_LOC_RET" ] && sed -i "s|LOCAL_RETENTION_DAYS=.*|LOCAL_RETENTION_DAYS=\"${NEW_LOC_RET}\"|" "$CONFIG_FILE"

    ok "Retensi diperbarui."
    echo ""
}

view_logs() {
    load_config
    print_header
    header "📋 Log Backup"
    echo ""
    echo -e "  ${CYAN}1)${NC} Tail log (live)"
    echo -e "  ${CYAN}2)${NC} Tampilkan 50 baris terakhir"
    echo -e "  ${CYAN}3)${NC} Cari error"
    echo ""
    read -rp "  → Pilihan: " log_choice
    case "$log_choice" in
        1) tail -f "$LOG_FILE" ;;
        2) tail -50 "$LOG_FILE" | less ;;
        3) grep -i "error\|fail\|gagal" "$LOG_FILE" | tail -30 ;;
        *) warn "Pilihan tidak valid." ;;
    esac
}

uninstall() {
    print_header
    header "🗑️  Uninstall PteroBackup"
    echo ""
    warn "Ini akan menghapus semua konfigurasi dan script PteroBackup."
    warn "Backup yang sudah ada di Google Drive tidak akan dihapus."
    echo ""
    read -rp "  → Ketik 'HAPUS' untuk konfirmasi: " confirm
    if [ "$confirm" != "HAPUS" ]; then
        info "Dibatalkan."; return
    fi

    systemctl stop ptero-backup.timer 2>/dev/null || true
    systemctl disable ptero-backup.timer 2>/dev/null || true
    rm -f /etc/systemd/system/ptero-backup.service
    rm -f /etc/systemd/system/ptero-backup.timer
    systemctl daemon-reload > /dev/null 2>&1

    sed -i '/ptero-backup/d' /etc/crontab 2>/dev/null || true
    rm -f /usr/local/bin/ptero-backup
    rm -f /usr/local/bin/ptero-backup-manage
    rm -rf /etc/ptero-backup

    ok "PteroBackup diuninstall."
    echo ""
}

# ── Command line shortcuts ────────────────────────────────────
case "${1:-}" in
    status)   show_status; exit 0 ;;
    run)      run_backup_now; exit 0 ;;
    logs)     view_logs; exit 0 ;;
    files)    list_drive_files; exit 0 ;;
esac

# ── Interactive menu ──────────────────────────────────────────
while true; do
    print_header

    # Quick status bar
    if [ -f "$CONFIG_FILE" ]; then
        source "$CONFIG_FILE" 2>/dev/null
        TIMER_STATUS=$(systemctl is-active ptero-backup.timer 2>/dev/null || echo "inactive")
        TIMER_COLOR="${GREEN}"; [ "$TIMER_STATUS" != "active" ] && TIMER_COLOR="${RED}"
        echo -e "  ${DIM}Host:${NC} $(hostname)   ${DIM}Timer:${NC} ${TIMER_COLOR}${TIMER_STATUS}${NC}   ${DIM}Remote:${NC} ${GDRIVE_REMOTE}:/${GDRIVE_FOLDER}"
    fi

    echo ""
    echo -e "  ${BOLD}Menu Utama${NC}"
    line
    echo -e "  ${CYAN}1)${NC} 📊 Lihat Status"
    echo -e "  ${CYAN}2)${NC} ▶️  Backup Sekarang"
    echo -e "  ${CYAN}3)${NC} ☁️  Lihat File di Drive"
    echo -e "  ${CYAN}4)${NC} ⏰ Ubah Jadwal"
    echo -e "  ${CYAN}5)${NC} 🔔 Update Discord Webhook"
    echo -e "  ${CYAN}6)${NC} 🗑️  Update Retensi"
    echo -e "  ${CYAN}7)${NC} 📋 Lihat Log"
    echo -e "  ${CYAN}8)${NC} 🔧 Rekonfigurasi rclone"
    echo -e "  ${CYAN}9)${NC} 🗑️  Uninstall"
    echo -e "  ${CYAN}0)${NC} Keluar"
    echo ""
    read -rp "  → Pilih [0-9]: " menu_choice

    case "$menu_choice" in
        1) show_status ;;
        2) run_backup_now ;;
        3) list_drive_files ;;
        4) change_schedule ;;
        5) update_webhook ;;
        6) update_retention ;;
        7) view_logs ;;
        8) rclone config ;;
        9) uninstall; break ;;
        0) echo ""; echo -e "  ${DIM}Sampai jumpa! 🦕${NC}"; echo ""; break ;;
        *) warn "Pilihan tidak valid." ;;
    esac

    echo ""; read -rp "  Tekan ENTER untuk kembali ke menu..." _
done
