#!/bin/bash
# ============================================================
#  PteroBackup — Interactive Installer v2.0
#  Headless OAuth: VPS generate authorize command → run di PC
#  → paste token back ke VPS
# ============================================================

set -e

# ── Colors ───────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; MAGENTA='\033[0;35m'
NC='\033[0m'; BOLD='\033[1m'; DIM='\033[2m'

# ── Helpers ──────────────────────────────────────────────────
print_banner() {
cat << 'EOF'

  ██████╗ ████████╗███████╗██████╗  ██████╗ ██████╗  █████╗  ██████╗██╗  ██╗██╗   ██╗██████╗
  ██╔══██╗╚══██╔══╝██╔════╝██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔════╝██║ ██╔╝██║   ██║██╔══██╗
  ██████╔╝   ██║   █████╗  ██████╔╝██║   ██║██████╔╝███████║██║     █████╔╝ ██║   ██║██████╔╝
  ██╔═══╝    ██║   ██╔══╝  ██╔══██╗██║   ██║██╔══██╗██╔══██║██║     ██╔═██╗ ██║   ██║██╔═══╝
  ██║        ██║   ███████╗██║  ██║╚██████╔╝██████╔╝██║  ██║╚██████╗██║  ██╗╚██████╔╝██║
  ╚═╝        ╚═╝   ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝

        🦕 Pterodactyl Wings Auto Backup — Installer v2.0
EOF
}

line()   { echo -e "${DIM}──────────────────────────────────────────────────────${NC}"; }
header() { echo -e "\n${BOLD}${CYAN}$1${NC}"; line; }
ok()     { echo -e "  ${GREEN}✔${NC}  $1"; }
info()   { echo -e "  ${BLUE}ℹ${NC}  $1"; }
warn()   { echo -e "  ${YELLOW}⚠${NC}  $1"; }
err()    { echo -e "  ${RED}✖${NC}  $1"; }
ask()    { echo -e "\n  ${MAGENTA}?${NC}  ${BOLD}$1${NC}"; }

confirm() {
    local default="${1:-y}"
    local yn
    if [ "$default" = "y" ]; then
        read -rp "  → [Y/n] " yn; yn="${yn:-y}"
    else
        read -rp "  → [y/N] " yn; yn="${yn:-n}"
    fi
    [[ "$yn" =~ ^[Yy] ]]
}

input() {
    local default="$1" val
    if [ -n "$default" ]; then
        read -rp "  → [$default]: " val
        echo "${val:-$default}"
    else
        read -rp "  → " val
        echo "$val"
    fi
}

# ── Root check ───────────────────────────────────────────────
check_root() {
    if [ "$EUID" -ne 0 ]; then
        err "Script ini harus dijalankan sebagai root."
        echo "  Coba: sudo bash install.sh"
        exit 1
    fi
}

# ── Detect OS ─────────────────────────────────────────────────
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS_ID="$ID"; OS_PRETTY="$PRETTY_NAME"
    else
        OS_ID="unknown"; OS_PRETTY="Unknown"
    fi
}

# ── Install rclone ───────────────────────────────────────────
install_rclone() {
    if command -v rclone &>/dev/null; then
        RCLONE_VER=$(rclone version 2>/dev/null | head -1)
        ok "rclone sudah terinstall: $RCLONE_VER"
        return
    fi
    info "Menginstall rclone..."
    curl -fsSL https://rclone.org/install.sh | bash > /dev/null 2>&1
    if command -v rclone &>/dev/null; then
        ok "rclone berhasil diinstall!"
    else
        err "Gagal install rclone. Install manual: https://rclone.org/install/"
        exit 1
    fi
}

# ── Install deps ──────────────────────────────────────────────
install_deps() {
    header "📦 Mengecek Dependencies"
    local missing=()
    command -v curl &>/dev/null || missing+=("curl")
    command -v zip  &>/dev/null || missing+=("zip")

    if [ ${#missing[@]} -gt 0 ]; then
        info "Installing: ${missing[*]}"
        case "$OS_ID" in
            ubuntu|debian) apt-get update -qq && apt-get install -y -qq "${missing[@]}" ;;
            centos|rhel|fedora|rocky|almalinux) yum install -y -q "${missing[@]}" ;;
            *) warn "OS tidak dikenal. Install manual: ${missing[*]}" ;;
        esac
    fi
    ok "Dependencies OK"
    install_rclone
}

# ════════════════════════════════════════════════════════════════
#  SETUP RCLONE — Headless OAuth persis seperti rclone config
#  Flow: VPS cetak command → user jalankan di PC → paste token
# ════════════════════════════════════════════════════════════════
setup_rclone() {
    header "☁️  Setup rclone Google Drive"

    local remote_name="gdrive"
    RCLONE_REMOTE_NAME="$remote_name"

    # ── Cek kalau sudah pernah setup dan masih valid ──────────
    if rclone listremotes 2>/dev/null | grep -q "^${remote_name}:"; then
        info "Remote '$remote_name' sudah ada, mengecek koneksi..."
        if rclone lsd "${remote_name}:" > /dev/null 2>&1; then
            ok "Google Drive masih terhubung! Lewati setup OAuth."
            return
        else
            warn "Token sudah tidak valid. Perlu authorize ulang."
            rclone config delete "$remote_name" > /dev/null 2>&1 || true
        fi
    fi

    # ── Tanya pakai OAuth app sendiri? ───────────────────────
    echo ""
    echo -e "  ${BOLD}Pakai OAuth App sendiri atau bawaan rclone?${NC}"
    echo ""
    echo -e "  ${CYAN}1)${NC} Bawaan rclone ${DIM}(mudah, cocok untuk personal)${NC}"
    echo -e "  ${CYAN}2)${NC} OAuth App sendiri ${DIM}(untuk produksi — butuh Google Cloud Console)${NC}"
    echo ""
    read -rp "  → Pilihan [1/2]: " oauth_choice

    local CLIENT_ID="" CLIENT_SECRET=""
    if [ "$oauth_choice" = "2" ]; then
        echo ""
        echo -e "  ${DIM}Cara buat OAuth App:${NC}"
        echo -e "  ${DIM}  1. Buka console.cloud.google.com → buat project${NC}"
        echo -e "  ${DIM}  2. APIs & Services → Enable → Google Drive API${NC}"
        echo -e "  ${DIM}  3. Credentials → Create → OAuth 2.0 Client ID → Desktop app${NC}"
        echo -e "  ${DIM}  4. Copy Client ID dan Client Secret${NC}"
        echo ""
        read -rp "  → Client ID     : " CLIENT_ID
        read -rsp "  → Client Secret : " CLIENT_SECRET
        echo ""
    fi

    # ── Tulis rclone config langsung ke file (no interactive) ──
    info "Membuat konfigurasi rclone..."
    local RCLONE_CONF_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/rclone"
    local RCLONE_CONF_FILE="$RCLONE_CONF_DIR/rclone.conf"
    mkdir -p "$RCLONE_CONF_DIR"

    # Hapus section lama kalau ada
    if [ -f "$RCLONE_CONF_FILE" ]; then
        python3 -c "
import configparser
c = configparser.RawConfigParser()
c.read('$RCLONE_CONF_FILE')
if '$remote_name' in c:
    c.remove_section('$remote_name')
with open('$RCLONE_CONF_FILE', 'w') as f:
    c.write(f)
" 2>/dev/null || sed -i "/^\[${remote_name}\]/,/^\[/{ /^\[${remote_name}\]/d; /^\[/!d }" "$RCLONE_CONF_FILE" 2>/dev/null || true
    fi

    # Tulis section baru langsung ke config file
    if [ -n "$CLIENT_ID" ] && [ -n "$CLIENT_SECRET" ]; then
        cat >> "$RCLONE_CONF_FILE" << RCLONECONF
[${remote_name}]
type = drive
client_id = ${CLIENT_ID}
client_secret = ${CLIENT_SECRET}
scope = drive
RCLONECONF
    else
        cat >> "$RCLONE_CONF_FILE" << RCLONECONF
[${remote_name}]
type = drive
scope = drive
RCLONECONF
    fi
    chmod 600 "$RCLONE_CONF_FILE"
    ok "Konfigurasi rclone ditulis ke $RCLONE_CONF_FILE" 

    # ── Generate authorize command (sama persis kayak rclone config) ──
    echo ""
    echo -e "  ${BOLD}${CYAN}╔══════════════════════════════════════════════════════╗${NC}"
    echo -e "  ${BOLD}${CYAN}║   🔐  Autentikasi Google Drive — Headless Mode        ║${NC}"
    echo -e "  ${BOLD}${CYAN}╚══════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "  VPS tidak punya browser, jadi kita pakai PC kamu untuk login."
    echo ""

    # Bangun rclone authorize command persis seperti rclone config tunjukkan
    local AUTH_CMD
    if [ -n "$CLIENT_ID" ] && [ -n "$CLIENT_SECRET" ]; then
        AUTH_CMD="rclone authorize \"drive\" \"${CLIENT_ID}\" \"${CLIENT_SECRET}\""
    else
        # Rclone encode client_id kosong sebagai string khusus
        # Gunakan mode tanpa client id — rclone pakai built-in
        AUTH_CMD="rclone authorize \"drive\""
    fi

    echo -e "  ${BOLD}${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "  ${BOLD}Langkah 1:${NC} Jalankan command ini di ${BOLD}PC/laptop${NC} kamu:"
    echo ""
    echo -e "  ${BOLD}${GREEN}  $AUTH_CMD${NC}"
    echo ""
    echo -e "  ${BOLD}${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo -e "  ${BOLD}Langkah 2:${NC} Browser akan terbuka → login Google → klik Allow"
    echo ""
    echo -e "  ${BOLD}Langkah 3:${NC} Terminal PC akan tampilkan token seperti ini:"
    echo ""
    echo -e "  ${DIM}  Paste the following into your remote machine --->${NC}"
    echo -e "  ${DIM}  {\"access_token\":\"ya29.xxx\",\"token_type\":\"Bearer\",...}${NC}"
    echo -e "  ${DIM}  <--- End paste${NC}"
    echo ""
    echo -e "  ${BOLD}Langkah 4:${NC} Copy token JSON tersebut → paste di bawah"
    echo ""

    # Kalau rclone belum ada di PC, kasih link download
    echo -e "  ${DIM}💡 Belum punya rclone di PC?${NC}"
    echo -e "  ${DIM}     Windows : https://rclone.org/downloads/${NC}"
    echo -e "  ${DIM}     macOS   : brew install rclone${NC}"
    echo -e "  ${DIM}     Linux   : curl https://rclone.org/install.sh | sudo bash${NC}"
    echo ""
    line

    # ── Tunggu user paste token ───────────────────────────────
    echo ""
    echo -e "  ${BOLD}${MAGENTA}Paste token JSON dari PC kamu, lalu tekan ENTER:${NC}"
    echo -e "  ${DIM}(mulai dari { sampai } termasuk tanda kurung kurawalnya)${NC}"
    echo ""
    read -rp "  config_token> " OAUTH_TOKEN
    echo ""

    # ── Validasi token ────────────────────────────────────────
    if [ -z "$OAUTH_TOKEN" ]; then
        err "Token kosong! Jalankan ulang installer dan ulangi proses OAuth."
        exit 1
    fi

    # Strip newline/carriage return SAJA — jangan pakai xargs (merusak JSON)
    OAUTH_TOKEN=$(printf '%s' "$OAUTH_TOKEN" | tr -d '\n\r')

    # Validasi pakai python3 — parse JSON beneran, bukan grep
    VALIDATE_RESULT=$(python3 -c "
import json, sys
try:
    raw = sys.stdin.buffer.read().decode('utf-8', errors='replace')
    data = json.loads(raw)
    if 'access_token' not in data:
        print('MISSING_ACCESS_TOKEN')
        sys.exit(1)
    print('OK')
except json.JSONDecodeError as e:
    print('JSON_ERROR: ' + str(e))
    sys.exit(1)
" <<< "$OAUTH_TOKEN" 2>&1)

    if [ "$VALIDATE_RESULT" != "OK" ]; then
        err "Token tidak valid: $VALIDATE_RESULT"
        echo ""
        echo -e "  ${DIM}Pastikan copy seluruh JSON dari { sampai } — jangan ada yang terpotong.${NC}"
        echo -e '  Contoh: {"access_token":"ya29.xxx","token_type":"Bearer","refresh_token":"1//0geN...","expiry":"2026-03-22T18:00:00+07:00","expires_in":3599}'
        exit 1
    fi

    ok "Format token valid ✓" 

    # ── Inject token ke rclone config (tulis langsung ke file) ──
    info "Menyimpan token ke konfigurasi rclone..."

    # Simpan token ke file temp dulu supaya aman dari special chars
    local TOKEN_TMPFILE
    TOKEN_TMPFILE=$(mktemp)
    printf '%s' "$OAUTH_TOKEN" > "$TOKEN_TMPFILE"

    # Tambahkan token = ... ke dalam section di config file
    local TMPCONF
    TMPCONF=$(mktemp)

    awk -v section="[${remote_name}]" -v tokenfile="$TOKEN_TMPFILE" '
        BEGIN { in_sec=0; added=0 }
        /^\[/ {
            if (in_sec && !added) {
                # Inject token sebelum section berikutnya
                token=""; while ((getline line < tokenfile) > 0) token=token line
                close(tokenfile)
                print "token = " token
                added=1
            }
            in_sec = ($0 == section)
        }
        in_sec && /^token[ \t]*=/ {
            # Ganti token yang ada
            if (!added) {
                token=""; while ((getline line < tokenfile) > 0) token=token line
                close(tokenfile)
                print "token = " token
                added=1
            }
            next
        }
        { print }
        END {
            if (in_sec && !added) {
                token=""; while ((getline line < tokenfile) > 0) token=token line
                print "token = " token
            }
        }
    ' "$RCLONE_CONF_FILE" > "$TMPCONF"

    mv "$TMPCONF" "$RCLONE_CONF_FILE"
    rm -f "$TOKEN_TMPFILE"
    chmod 600 "$RCLONE_CONF_FILE"

    # ── Verifikasi koneksi ────────────────────────────────────
    echo ""
    info "Memverifikasi koneksi ke Google Drive..."
    sleep 1

    if rclone lsd "${remote_name}:" --contimeout 15s --timeout 30s > /dev/null 2>&1; then
        ok "✨ Google Drive berhasil terhubung!"
        DRIVE_INFO=$(rclone about "${remote_name}:" --contimeout 10s 2>/dev/null | grep -E "Total|Used|Free" | head -3 | sed 's/^/     /')
        [ -n "$DRIVE_INFO" ] && echo -e "${DIM}${DRIVE_INFO}${NC}"
    else
        err "Koneksi gagal. Kemungkinan penyebab:"
        echo -e "  ${DIM}• Token tidak lengkap / salah copy${NC}"
        echo -e "  ${DIM}• Token sudah expired (jalankan ulang authorize di PC)${NC}"
        echo -e "  ${DIM}• OAuth app salah konfigurasi${NC}"
        echo ""
        echo -e "  Cek config: ${YELLOW}cat ${RCLONE_CONF_FILE}${NC}"
        echo -e "  Debug     : ${YELLOW}rclone lsd gdrive: -vv${NC}"
        exit 1
    fi
}

# ── Main installer logic ──────────────────────────────────────
main() {
    clear
    print_banner
    echo ""
    check_root
    detect_os

    header "🖥️  Sistem Terdeteksi"
    ok "OS       : $OS_PRETTY"
    ok "Hostname : $(hostname)"
    ok "User     : $(whoami)"
    ok "Date     : $(date '+%d %b %Y %H:%M:%S')"

    echo ""
    echo -e "  ${BOLD}Installer ini akan setup:${NC}"
    echo -e "  ${DIM}• Backup script untuk Pterodactyl Wings${NC}"
    echo -e "  ${DIM}• rclone + OAuth Google Drive (headless — authorize via PC)${NC}"
    echo -e "  ${DIM}• Penamaan folder otomatis berdasarkan hostname VPS${NC}"
    echo -e "  ${DIM}• Discord webhook notifications${NC}"
    echo -e "  ${DIM}• Jadwal backup otomatis (systemd timer)${NC}"
    echo ""
    if ! confirm "y"; then
        echo "Installer dibatalkan."; exit 0
    fi

    # ── Install deps ──────────────────────────────────────────
    install_deps

    # ── Source Directory ──────────────────────────────────────
    header "📂 Direktori Backup"
    echo ""
    echo -e "  ${DIM}Default: /var/lib/pterodactyl${NC}"
    ask "Direktori yang akan dibackup"
    BACKUP_SOURCE_DIR=$(input "/var/lib/pterodactyl")

    if [ ! -d "$BACKUP_SOURCE_DIR" ]; then
        warn "Direktori '$BACKUP_SOURCE_DIR' tidak ditemukan."
        if ! confirm "n"; then exit 1; fi
    else
        SOURCE_SIZE=$(du -sh "$BACKUP_SOURCE_DIR" 2>/dev/null | cut -f1)
        ok "Source: $BACKUP_SOURCE_DIR (${SOURCE_SIZE})"
    fi

    BACKUP_TEMP_DIR="/tmp/ptero-backup-temp"
    BACKUP_LOCAL_DIR="/var/backups/pterodactyl"

    ask "Simpan salinan lokal juga? (selain Drive)"
    if confirm "n"; then
        KEEP_LOCAL_COPY="true"
        ok "Salinan lokal aktif: $BACKUP_LOCAL_DIR"
    else
        KEEP_LOCAL_COPY="false"
    fi

    # ── Setup rclone OAuth ────────────────────────────────────
    setup_rclone

    # ── Folder Drive berdasarkan hostname ─────────────────────
    header "📁 Folder Google Drive"
    HOSTNAME_CLEAN=$(hostname | tr '.' '-' | tr '[:upper:]' '[:lower:]')
    DEFAULT_FOLDER="backup-${HOSTNAME_CLEAN}"

    echo ""
    echo -e "  ${DIM}Hostname VPS ini : ${BOLD}$(hostname)${NC}"
    echo -e "  ${DIM}Folder default   : ${BOLD}${DEFAULT_FOLDER}${NC}"
    echo ""
    echo -e "  Backup akan disimpan di:"
    echo -e "  ${CYAN}☁️  My Drive / ${DEFAULT_FOLDER} / ptero-backup_${HOSTNAME_CLEAN}_YYYYMMDD.zip${NC}"
    echo ""
    ask "Nama folder di Google Drive (kosongkan untuk pakai default)"
    GDRIVE_FOLDER=$(input "$DEFAULT_FOLDER")

    # ── Retention ─────────────────────────────────────────────
    header "🗑️  Retensi & Cleanup"
    echo ""
    ask "Hapus backup di Drive lebih dari berapa hari? (0 = jangan hapus)"
    RETENTION_DAYS=$(input "7")

    ask "Hapus backup lokal lebih dari berapa hari?"
    LOCAL_RETENTION_DAYS=$(input "3")

    # ── Discord ───────────────────────────────────────────────
    header "🔔 Discord Webhook"
    echo ""
    echo -e "  ${DIM}Cara dapat webhook: Discord → Server Settings → Integrations → Webhooks${NC}"
    echo ""
    ask "Discord Webhook URL (kosongkan untuk skip)"
    DISCORD_WEBHOOK_URL=$(input "")

    if [ -n "$DISCORD_WEBHOOK_URL" ]; then
        info "Mengirim test notification ke Discord..."
        HOSTNAME_NOW=$(hostname)
        curl -s -X POST \
            -H "Content-Type: application/json" \
            -d "{
              \"username\": \"PteroBackup 🦕\",
              \"embeds\": [{
                \"title\": \"🔧 PteroBackup Terpasang!\",
                \"description\": \"Installer selesai di \`${HOSTNAME_NOW}\`. Backup otomatis sudah siap! 🎉\",
                \"color\": 3066993,
                \"footer\": {\"text\": \"PteroBackup v2.0\"}
              }]
            }" \
            "$DISCORD_WEBHOOK_URL" > /dev/null 2>&1 \
            && ok "Test webhook terkirim!" \
            || warn "Gagal kirim test (cek URL webhook)"
    else
        warn "Discord webhook dilewati"
    fi

    # ── Schedule ──────────────────────────────────────────────
    header "⏰ Jadwal Backup Otomatis"
    echo ""
    echo -e "  ${BOLD}Pilih interval backup:${NC}"
    echo ""
    echo -e "  ${CYAN}1)${NC} Setiap 6 jam"
    echo -e "  ${CYAN}2)${NC} Setiap 12 jam"
    echo -e "  ${CYAN}3)${NC} Setiap 24 jam (jam 02:00 dini hari)"
    echo -e "  ${CYAN}4)${NC} Setiap 2 jam"
    echo -e "  ${CYAN}5)${NC} Custom cron expression"
    echo ""
    read -rp "  → Pilihan [1-5]: " sched_choice

    case "$sched_choice" in
        1) CRON_SCHEDULE="0 */6 * * *";   SYSTEMD_CAL="*-*-* 00,06,12,18:00:00";              SCHEDULE_DESC="Setiap 6 jam" ;;
        2) CRON_SCHEDULE="0 */12 * * *";  SYSTEMD_CAL="*-*-* 00,12:00:00";                    SCHEDULE_DESC="Setiap 12 jam" ;;
        3) CRON_SCHEDULE="0 2 * * *";     SYSTEMD_CAL="*-*-* 02:00:00";                       SCHEDULE_DESC="Setiap hari jam 02:00" ;;
        4) CRON_SCHEDULE="0 */2 * * *";   SYSTEMD_CAL="*-*-* 00,02,04,06,08,10,12,14,16,18,20,22:00:00"; SCHEDULE_DESC="Setiap 2 jam" ;;
        5)
            ask "Cron expression (misal: 0 3 * * *)"
            CRON_SCHEDULE=$(input "0 2 * * *")
            SYSTEMD_CAL="*-*-* 02:00:00"
            SCHEDULE_DESC="Custom: $CRON_SCHEDULE"
            ;;
        *) CRON_SCHEDULE="0 2 * * *"; SYSTEMD_CAL="*-*-* 02:00:00"; SCHEDULE_DESC="Setiap hari jam 02:00 (default)" ;;
    esac
    ok "Jadwal: $SCHEDULE_DESC"

    # ── Ringkasan ─────────────────────────────────────────────
    header "📋 Ringkasan Konfigurasi"
    echo ""
    echo -e "  ${BOLD}Source         :${NC} $BACKUP_SOURCE_DIR"
    echo -e "  ${BOLD}Simpan Lokal   :${NC} $KEEP_LOCAL_COPY"
    echo -e "  ${BOLD}rclone Remote  :${NC} $RCLONE_REMOTE_NAME"
    echo -e "  ${BOLD}Drive Folder   :${NC} $GDRIVE_FOLDER"
    echo -e "  ${BOLD}Nama Archive   :${NC} ptero-backup_${HOSTNAME_CLEAN}_YYYYMMDD_HHMMSS.zip"
    echo -e "  ${BOLD}Retention Drive:${NC} ${RETENTION_DAYS} hari"
    echo -e "  ${BOLD}Retention Lokal:${NC} ${LOCAL_RETENTION_DAYS} hari"
    echo -e "  ${BOLD}Discord Webhook:${NC} ${DISCORD_WEBHOOK_URL:-(tidak dikonfigurasi)}"
    echo -e "  ${BOLD}Jadwal         :${NC} $CRON_SCHEDULE ($SCHEDULE_DESC)"
    echo ""

    if ! confirm "y"; then
        echo "Dibatalkan."; exit 0
    fi

    # ── Tulis config ──────────────────────────────────────────
    header "🔧 Menginstall..."

    mkdir -p /etc/ptero-backup /var/log/ptero-backup "$BACKUP_TEMP_DIR" "$BACKUP_LOCAL_DIR"

    cat > /etc/ptero-backup/config.env << CONF
# PteroBackup Configuration
# Generated: $(date '+%Y-%m-%d %H:%M:%S')
# Host     : $(hostname)

BACKUP_SOURCE_DIR="${BACKUP_SOURCE_DIR}"
BACKUP_TEMP_DIR="${BACKUP_TEMP_DIR}"
BACKUP_LOCAL_DIR="${BACKUP_LOCAL_DIR}"
KEEP_LOCAL_COPY="${KEEP_LOCAL_COPY}"

GDRIVE_REMOTE="${RCLONE_REMOTE_NAME}"
GDRIVE_FOLDER="${GDRIVE_FOLDER}"

RETENTION_DAYS="${RETENTION_DAYS}"
LOCAL_RETENTION_DAYS="${LOCAL_RETENTION_DAYS}"

DISCORD_WEBHOOK_URL="${DISCORD_WEBHOOK_URL}"
CONF
    chmod 600 /etc/ptero-backup/config.env
    ok "Config → /etc/ptero-backup/config.env"

    # Install scripts
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    install -m 755 "${SCRIPT_DIR}/backup.sh"  /usr/local/bin/ptero-backup
    install -m 755 "${SCRIPT_DIR}/manage.sh"  /usr/local/bin/ptero-backup-manage
    ok "Scripts → /usr/local/bin/"

    # Systemd service
    cat > /etc/systemd/system/ptero-backup.service << 'SVCEOF'
[Unit]
Description=Pterodactyl Wings Auto Backup
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/ptero-backup
StandardOutput=append:/var/log/ptero-backup/backup.log
StandardError=append:/var/log/ptero-backup/backup.log
User=root
SVCEOF

    # Systemd timer
    cat > /etc/systemd/system/ptero-backup.timer << TIMEREOF
[Unit]
Description=Pterodactyl Wings Backup Timer
Requires=ptero-backup.service

[Timer]
OnCalendar=${SYSTEMD_CAL}
Persistent=true

[Install]
WantedBy=timers.target
TIMEREOF

    systemctl daemon-reload > /dev/null 2>&1
    systemctl enable ptero-backup.timer > /dev/null 2>&1
    systemctl start  ptero-backup.timer > /dev/null 2>&1
    ok "Systemd timer aktif: $SCHEDULE_DESC"

    # Crontab fallback
    sed -i '/ptero-backup/d' /etc/crontab 2>/dev/null || true
    echo "$CRON_SCHEDULE root /usr/local/bin/ptero-backup >> /var/log/ptero-backup/backup.log 2>&1" >> /etc/crontab
    ok "Cron fallback ditambahkan"

    # ── Done ──────────────────────────────────────────────────
    echo ""
    line
    echo -e "  ${BOLD}${GREEN}🎉 Instalasi Selesai!${NC}"
    line
    echo ""
    echo -e "  ${BOLD}Commands yang bisa dipakai:${NC}"
    echo ""
    echo -e "  ${CYAN}ptero-backup${NC}              → Backup sekarang"
    echo -e "  ${CYAN}ptero-backup-manage${NC}       → Panel manajemen interaktif"
    echo -e "  ${CYAN}ptero-backup-manage status${NC} → Status cepat"
    echo ""
    echo -e "  ${BOLD}Log    :${NC} /var/log/ptero-backup/backup.log"
    echo -e "  ${BOLD}Config :${NC} /etc/ptero-backup/config.env"
    echo -e "  ${BOLD}Drive  :${NC} $GDRIVE_FOLDER/"
    echo ""

    if confirm "y"; then
        echo ""
        /usr/local/bin/ptero-backup
    fi
}

main "$@"
