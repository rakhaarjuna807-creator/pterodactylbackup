#!/bin/bash
# ============================================================
#  Pterodactyl Wings Auto Backup
#  by PteroBackup — github.com/your-repo
# ============================================================

CONFIG_FILE="/etc/ptero-backup/config.env"
LOG_FILE="/var/log/ptero-backup/backup.log"
LOCK_FILE="/tmp/ptero-backup.lock"

# Load config
if [ ! -f "$CONFIG_FILE" ]; then
    echo "ERROR: Config file not found at $CONFIG_FILE. Run installer first."
    exit 1
fi
source "$CONFIG_FILE"

# ── Colors (for log readability) ────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'; BOLD='\033[1m'

# ── Helpers ──────────────────────────────────────────────────
log() { echo -e "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"; }
log_info()    { log "${BLUE}[INFO]${NC}  $1"; }
log_ok()      { log "${GREEN}[OK]${NC}    $1"; }
log_warn()    { log "${YELLOW}[WARN]${NC}  $1"; }
log_error()   { log "${RED}[ERROR]${NC} $1"; }

# ── Discord Webhook ──────────────────────────────────────────
send_discord() {
    local type="$1"   # start | success | fail | info
    local title="$2"
    local desc="$3"
    local extra_fields="$4"

    [ -z "$DISCORD_WEBHOOK_URL" ] && return 0

    local color timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

    case "$type" in
        start)   color=3447003   ;;   # blue
        success) color=3066993   ;;   # green
        fail)    color=15158332  ;;   # red
        warn)    color=16776960  ;;   # yellow
        *)       color=9807270   ;;   # grey
    esac

    local footer_text="PteroBackup • $(hostname)"
    local thumbnail_url="https://cdn.discordapp.com/emojis/1234567890.png"

    # Build fields JSON
    local fields_json="[]"
    if [ -n "$extra_fields" ]; then
        fields_json="$extra_fields"
    fi

    local payload
    payload=$(cat <<EOF
{
  "username": "PteroBackup 🦕",
  "avatar_url": "https://avatars.githubusercontent.com/u/74684787?s=200&v=4",
  "embeds": [{
    "title": "$title",
    "description": "$desc",
    "color": $color,
    "fields": $fields_json,
    "footer": {
      "text": "$footer_text",
      "icon_url": "https://pterodactyl.io/pterodactyl.png"
    },
    "timestamp": "$timestamp"
  }]
}
EOF
)
    curl -s -X POST \
        -H "Content-Type: application/json" \
        -d "$payload" \
        "$DISCORD_WEBHOOK_URL" > /dev/null 2>&1
}

send_discord_file() {
    local file_path="$1"
    local message="$2"
    [ -z "$DISCORD_WEBHOOK_URL" ] && return 0
    [ ! -f "$file_path" ] && return 0
    curl -s -X POST \
        -F "payload_json={\"username\":\"PteroBackup 🦕\",\"content\":\"$message\"}" \
        -F "file=@$file_path" \
        "$DISCORD_WEBHOOK_URL" > /dev/null 2>&1
}

# ── Lock check ───────────────────────────────────────────────
if [ -f "$LOCK_FILE" ]; then
    LOCK_PID=$(cat "$LOCK_FILE")
    if kill -0 "$LOCK_PID" 2>/dev/null; then
        log_warn "Backup already running (PID $LOCK_PID). Skipping."
        send_discord "warn" "⚠️ Backup Skipped" \
            "Backup sudah berjalan (PID: \`$LOCK_PID\`). Proses ini dilewati." \
            '[{"name":"Host","value":"'"$(hostname)"'","inline":true},{"name":"Time","value":"'"$(date '+%H:%M:%S')"'","inline":true}]'
        exit 0
    fi
fi
echo $$ > "$LOCK_FILE"
trap 'rm -f "$LOCK_FILE"' EXIT

# ── Setup dirs ───────────────────────────────────────────────
mkdir -p "$BACKUP_TEMP_DIR" "$BACKUP_LOCAL_DIR"
mkdir -p "$(dirname "$LOG_FILE")"

# ══════════════════════════════════════════════════════════════
#  MAIN BACKUP LOGIC
# ══════════════════════════════════════════════════════════════
BACKUP_START_TIME=$(date +%s)
DATE_TAG=$(date '+%Y%m%d_%H%M%S')
HOSTNAME_CLEAN=$(hostname | tr '.' '-')
ARCHIVE_NAME="ptero-backup_${HOSTNAME_CLEAN}_${DATE_TAG}.zip"
ARCHIVE_PATH="${BACKUP_TEMP_DIR}/${ARCHIVE_NAME}"
LOG_SNIPPET="/tmp/ptero-backup-snippet.log"

log_info "═══════════════════════════════════════════"
log_info " Starting Pterodactyl Wings Backup"
log_info "═══════════════════════════════════════════"
log_info "Source    : $BACKUP_SOURCE_DIR"
log_info "Archive   : $ARCHIVE_NAME"
log_info "Drive Dir : $GDRIVE_FOLDER"

# ── Discord: Backup Start ────────────────────────────────────
send_discord "start" "🔄 Backup Dimulai" \
    "Pterodactyl Wings backup sedang berjalan..." \
    '[
      {"name":"📂 Source","value":"'"$BACKUP_SOURCE_DIR"'","inline":true},
      {"name":"🗜️ Archive","value":"'"$ARCHIVE_NAME"'","inline":true},
      {"name":"☁️ Destination","value":"'"$GDRIVE_FOLDER"'","inline":true},
      {"name":"🖥️ Host","value":"'"$(hostname)"'","inline":true},
      {"name":"🕐 Started At","value":"'"$(date '+%d %b %Y %H:%M:%S')"'","inline":true}
    ]'

# ── Step 1: Check source ─────────────────────────────────────
if [ ! -d "$BACKUP_SOURCE_DIR" ]; then
    log_error "Source directory '$BACKUP_SOURCE_DIR' does not exist!"
    send_discord "fail" "❌ Backup Gagal" \
        "Source directory tidak ditemukan: \`$BACKUP_SOURCE_DIR\`" \
        '[{"name":"💥 Error","value":"Directory not found","inline":false}]'
    exit 1
fi

SOURCE_SIZE=$(du -sh "$BACKUP_SOURCE_DIR" 2>/dev/null | cut -f1)
log_info "Source size: $SOURCE_SIZE"

# ── Step 2: Create archive ───────────────────────────────────
log_info "Creating compressed archive (zip)..."
COMPRESS_START=$(date +%s)

# Pastikan zip tersedia
if ! command -v zip &>/dev/null; then
    log_error "zip tidak ditemukan! Install dulu: apt install zip"
    send_discord "fail" "❌ Backup Gagal" \
        "Dependency \`zip\` tidak ditemukan di server." \
        '[{"name":"💥 Step","value":"Dependency check","inline":true},{"name":"💡 Fix","value":"apt install zip","inline":true}]'
    exit 1
fi

# zip exit codes:
#   0 = sukses
#   1 = warning (file berubah/skip) → TIDAK fatal, normal untuk server aktif
#   2+ = error fatal
# Catatan:
#   - Pakai subshell (cd ...) agar working dir script utama tidak ikut berubah
#   - Flag -y DIHAPUS: pterodactyl volumes banyak broken symlinks → zip exit 18
#   - $ARCHIVE_PATH pakai path absolut, aman dipanggil dari dalam subshell
(
    cd "$(dirname "$BACKUP_SOURCE_DIR")" || exit 2
    zip -rq "$ARCHIVE_PATH" \
        "$(basename "$BACKUP_SOURCE_DIR")" \
        --exclude="*.sock" \
        --exclude="*.pid" \
        2>>"$LOG_FILE"
)
ZIP_EXIT=$?

COMPRESS_END=$(date +%s)
COMPRESS_TIME=$((COMPRESS_END - COMPRESS_START))

# zip exit code reference:
#   0  = sukses bersih
#   1  = warning: ada file yang berubah saat dibaca (normal, server aktif)
#   18 = warning: ada file/symlink yang tidak bisa dibaca (normal di pterodactyl volumes)
#   2+ = error fatal (disk penuh, permission denied, dll)
if [ $ZIP_EXIT -eq 0 ]; then
    ARCHIVE_SIZE=$(du -sh "$ARCHIVE_PATH" 2>/dev/null | cut -f1)
    log_ok "Archive created: $ARCHIVE_SIZE (${COMPRESS_TIME}s)"
elif [ $ZIP_EXIT -eq 1 ] || [ $ZIP_EXIT -eq 18 ]; then
    # Non-fatal: file berubah saat dibaca (1) atau ada file tidak terbaca/broken symlink (18)
    # Kedua kondisi ini normal pada server pterodactyl yang sedang aktif
    ARCHIVE_SIZE=$(du -sh "$ARCHIVE_PATH" 2>/dev/null | cut -f1)
    log_warn "Archive selesai dengan warning (exit $ZIP_EXIT — file berubah atau symlink tidak valid, normal). Size: $ARCHIVE_SIZE (${COMPRESS_TIME}s)"
else
    # Fatal: disk penuh, permission denied, atau error lain
    log_error "Failed to create archive! (zip exit code: $ZIP_EXIT)"
    send_discord "fail" "❌ Backup Gagal" \
        "Gagal membuat archive. Cek log di server." \
        '[{"name":"💥 Step","value":"Compression (zip)","inline":true},{"name":"📁 Source","value":"'"$BACKUP_SOURCE_DIR"'","inline":true},{"name":"🔢 Exit Code","value":"'"$ZIP_EXIT"'","inline":true}]'
    exit 1
fi

# ── Step 3: Upload ke Google Drive via rclone ────────────────
log_info "Uploading to Google Drive: $GDRIVE_REMOTE:$GDRIVE_FOLDER/"
UPLOAD_START=$(date +%s)

if rclone copy "$ARCHIVE_PATH" "${GDRIVE_REMOTE}:${GDRIVE_FOLDER}/" \
    --progress \
    --stats-one-line \
    --log-file="$LOG_FILE" \
    --log-level=INFO 2>&1; then
    UPLOAD_END=$(date +%s)
    UPLOAD_TIME=$((UPLOAD_END - UPLOAD_START))
    log_ok "Upload successful (${UPLOAD_TIME}s)"
else
    log_error "Upload to Google Drive failed!"
    send_discord "fail" "❌ Upload Gagal" \
        "Archive berhasil dibuat tapi gagal diupload ke Google Drive." \
        '[{"name":"💥 Step","value":"rclone upload","inline":true},{"name":"📦 Archive","value":"'"$ARCHIVE_NAME"'","inline":true},{"name":"💡 Tip","value":"Cek `rclone config` dan OAuth token","inline":false}]'
    # cleanup temp
    rm -f "$ARCHIVE_PATH"
    exit 1
fi

# ── Step 4: Cleanup old backups di Google Drive ───────────────
if [ "${RETENTION_DAYS:-7}" -gt 0 ]; then
    log_info "Cleaning old backups older than ${RETENTION_DAYS} days from Drive..."
    rclone delete "${GDRIVE_REMOTE}:${GDRIVE_FOLDER}/" \
        --min-age "${RETENTION_DAYS}d" \
        --log-file="$LOG_FILE" \
        --log-level=INFO 2>&1
    DELETED_COUNT=$(rclone ls "${GDRIVE_REMOTE}:${GDRIVE_FOLDER}/" 2>/dev/null | wc -l)
    log_ok "Drive retention cleanup done. Current files in Drive: $DELETED_COUNT"
fi

# ── Step 5: Cleanup old local backups ────────────────────────
if [ -d "$BACKUP_LOCAL_DIR" ] && [ "${LOCAL_RETENTION_DAYS:-3}" -gt 0 ]; then
    log_info "Cleaning local backups older than ${LOCAL_RETENTION_DAYS} days..."
    find "$BACKUP_LOCAL_DIR" -name "ptero-backup_*.zip" \
        -mtime +"$LOCAL_RETENTION_DAYS" -delete 2>>"$LOG_FILE"
    log_ok "Local cleanup done."
fi

# ── Step 6: (Optional) Save local copy ───────────────────────
if [ "${KEEP_LOCAL_COPY:-false}" = "true" ]; then
    cp "$ARCHIVE_PATH" "${BACKUP_LOCAL_DIR}/${ARCHIVE_NAME}"
    log_ok "Local copy saved to $BACKUP_LOCAL_DIR"
fi

# ── Step 7: Remove temp archive ──────────────────────────────
rm -f "$ARCHIVE_PATH"
log_ok "Temp archive removed."

# ── Calculate total time ──────────────────────────────────────
BACKUP_END_TIME=$(date +%s)
TOTAL_TIME=$((BACKUP_END_TIME - BACKUP_START_TIME))
TOTAL_FMT=$(printf '%02d:%02d' $((TOTAL_TIME/60)) $((TOTAL_TIME%60)))

log_ok "═══════════════════════════════════════════"
log_ok " Backup SELESAI dalam ${TOTAL_FMT} menit"
log_ok "═══════════════════════════════════════════"

# ── Discord: Success ─────────────────────────────────────────
DRIVE_FILES=$(rclone ls "${GDRIVE_REMOTE}:${GDRIVE_FOLDER}/" 2>/dev/null | wc -l)
send_discord "success" "✅ Backup Berhasil!" \
    "Pterodactyl Wings backup selesai dan sudah diupload ke Google Drive! 🎉" \
    '[
      {"name":"📦 Archive","value":"'"$ARCHIVE_NAME"'","inline":false},
      {"name":"📊 Source Size","value":"'"$SOURCE_SIZE"'","inline":true},
      {"name":"🗜️ Archive Size","value":"'"$ARCHIVE_SIZE"'","inline":true},
      {"name":"⏱️ Total Time","value":"'"${TOTAL_FMT} menit"'","inline":true},
      {"name":"☁️ Drive Folder","value":"'"$GDRIVE_FOLDER"'","inline":true},
      {"name":"📁 Files in Drive","value":"'"$DRIVE_FILES file(s)"'","inline":true},
      {"name":"🗑️ Retention","value":"'"${RETENTION_DAYS} hari"'","inline":true}
    ]'

exit 0
